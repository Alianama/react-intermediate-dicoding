import {
  require_react
} from "./chunk-PSZ65TEE.js";
import "./chunk-TCQZMY3T.js";
export default require_react();
//# sourceMappingURL=react.js.map
